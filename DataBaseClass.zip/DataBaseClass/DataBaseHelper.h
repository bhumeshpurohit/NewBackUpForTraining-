//
//  DataBaseHelper.h
//  JobManagement
//
//  Created by Ravi on 27/11/13.
//  Copyright (c) 2013 Aarin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>

@interface DataBaseHelper : NSObject

-(NSMutableArray*)getproductlistFromProductType:(int)indexValue;
-(NSMutableArray*)getproductImage:(NSString *)productDescName;

@end
